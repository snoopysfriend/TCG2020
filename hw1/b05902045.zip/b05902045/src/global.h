// This file define the global variables
//
//


int N; // the height of the board
int M; // the width of the board 
int boardSize;
unsigned long long RES = 0;
char globalBoard[16][16]; // the global board to store 


